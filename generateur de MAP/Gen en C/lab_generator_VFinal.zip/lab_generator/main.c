#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){

	char codeGen;
	char* codes[69]={"00010000","00010100","00010101","00010102","00010103","00010200","00010201","00010202","00010203","00010300",
					  "00010301","00010302","00010303","00010400","00010500","00010501","00010502","00010503","00020000","00020100",
					  "00020101","00020102","00020103","00020200","00020201","00020202","00020203","00020300","00020301","00020302",
					  "00020303","00020400","00020500","00020501","00020502","00020503","00030000","00040000","00050000","01000000",
					  "01010000","01010100","01010101","01010102","01010103","01010200","01010201","01010202","01010203","01010300",
					  "01010301","01010302","01010303","01010400","01010500","01010501","01010502","01010503","01020000","01020100",
					  "01020101","01020102","01020103","01020200","01020201","01020202","01020203","01020300","01020301","01020302",
					  "01020303","01020400","01020500","01020501","01020502","01020503","01030000","01040000","01050000"};

	char *name[10];
	char *status[10];
	char *ident[10];
	char *maxplayers[10];
	char *hauteur[10];
	char *largeur[10];
	char *timeout[10];
	char *fovdefault[10];
	char *coins[10];
	char *chest[10];
	char *potion[10];
	char *rule[10];
	char *value[10];

	int nbcoin=0;
	int nbcoinOld=0;
	int coinGen=0;
	int nbpopo=0;
	int nbpopoOld=0;
	int popoGen=0;

	printf("\nname: ");
	fgets(name,10,stdin);
	printf("\nstatus ");
	fgets(status,10,stdin);
	printf("\nid ");
	fgets(ident,10,stdin);
	printf("\nmaxplayers ");
	fgets(maxplayers,10,stdin);
	printf("\nhauteur ");
	fgets(hauteur,10,stdin);
	printf("\nlargeur ");
	fgets(largeur,10,stdin);
	printf("\ntimeout ");
	fgets(timeout,10,stdin);
	printf("\nfovdefault ");
	fgets(fovdefault,10,stdin);
	printf("\ncoins ");
	fgets(coins,10,stdin);
	printf("\nchest ");
	fgets(chest,10,stdin);
	printf("\npotion ");
	fgets(potion,10,stdin);
	printf("\nrule ");
	fgets(rule,10,stdin);
	printf("\nvalue ");
	fgets(value,10,stdin);
	printf("\n");

	// faire un uppercase pour le probleme toTO

	FILE* fichier = NULL;
	fichier = fopen("lab_result.json", "w");

	fprintf(fichier, "{\n\"name\":\"%s\",",name );
	fprintf(fichier, "\n\"id\":%s,\n", ident);
	fprintf(fichier, "\n\"status\":\"");
	fprintf(fichier, "%s", status);
	fprintf(fichier, "\",\n\"turn\":5,\n\"currentPlayer\":\"tata\",\n");
	fprintf(fichier, "\"players\":[\"tata\",\"toto\",\"titi\"],\n\"maxPlayers\":");
	fprintf(fichier, "%s", maxplayers);
	fprintf(fichier, ",\n\"timeout\":");
	fprintf(fichier, "%s", timeout);
	fprintf(fichier, ",\n\"nbItems\":{\"coins\":");
	fprintf(fichier, "%s", coins);
	fprintf(fichier, ",\"chest\":");
	fprintf(fichier, "%s", chest);
	fprintf(fichier, ",\"potion\":");
	fprintf(fichier, "%s", potion);
	fprintf(fichier, "},\n\"nbItemsLeft\":{\"coins\":5,\"potion\":7},\n\"fovDefault\":");
	fprintf(fichier, "%s", fovdefault);
	fprintf(fichier, ",\n\"victoryOn\":{\"rule\":\"");
	fprintf(fichier, "%s", rule);
	fprintf(fichier, "\",\"value\":");
	fprintf(fichier, "%s", value);
	fprintf(fichier, "},\n\"ranking\":[\"titi\"],\n");
	fprintf(fichier, "\"inventory\":{\"coins\":5,\"potions\":[{\"kind\":\"immunity\"},{\"kind\":\"lottery-win\"}]},\n");
	fprintf(fichier, "\"activePotion\":null,\n\"width\":");
	fprintf(fichier, "%s", largeur);
	fprintf(fichier, ",\n\"height\":");
	fprintf(fichier, "%s", hauteur);
	fprintf(fichier, ",\n\"mapView\" : [\n");

	//génération de la MAP hauteur x largeur
	for (int i = 0; i < atoi(hauteur)+1; i++) {

		for (int j = 0; j < atoi(largeur)+1; j++) {

			fprintf(fichier, "[{\"x\" : ");
			char str1[10];
			sprintf(str1, "%d", i);
			fprintf(fichier, str1);


			fprintf(fichier, " , \"y\" : ");
			char str2[10];
			sprintf(str2, "%d", j);
			fprintf(fichier, str2);

			fprintf(fichier, " , \"isObstacle\" : \"");

			codeGen = rand() % 68 + 1;  //chiffre random entre 1 et 102 pour la liste de codes
			//condition de bordure pour faire un mur infranchissable
			if (i==0 || i==atoi(hauteur) || j==0 || j==atoi(largeur)){
				codeGen = 39; //adresse du tableau pour le mur infrancissable
			}

			//printf("%c",codes[codeGen][1]);

			if (codes[codeGen][1] == '1') {  //infranchissable
				fprintf(fichier, "true\"");
			}
			else if (codes[codeGen][1] == '0') {  //franchissable
				fprintf(fichier, "false\"");
			}

			fprintf(fichier, ", \"skin\"   : \"");
			fprintf(fichier, codes[codeGen]);

			if (i == atoi(hauteur) && j == atoi(largeur)) {
				fprintf(fichier, "\",\"players\":[],\"contains\":{\"kind\":\"\",\"skin\":\"\"}}]");
			}

			else {

				fprintf(fichier, "\",\"players\":[],\"contains\":{\"kind\":\"");
				// GEN DE COINS
				if (nbcoin <atoi(coins)){
					coinGen = rand() % 20 + 1;
					if (coinGen ==5){
						fprintf(fichier,"coin");
						fprintf(fichier, "\",\"skin\":\"02000000\"}}],");
						nbcoin++;
					}
				}

				// GEN DE POPO
				if (nbpopo <atoi(potion)){
					popoGen = rand() % 20 + 1;
					if (popoGen ==5){
						fprintf(fichier,"potion");
						fprintf(fichier, "\",\"skin\":\"02010000\"}}],");
						nbpopo++;
					}
				}
				printf("%d", nbcoin);
				printf("%d  ", nbcoinOld);
				printf("%d", nbpopo);
				printf("%d\n", nbpopoOld);


				if(nbpopo==nbpopoOld && nbcoin==nbcoinOld){
					fprintf(fichier, "\",\"skin\":\"\"}}],");
				}
				else{
					nbpopo=nbpopoOld;
					nbcoin=nbcoinOld;
				}

			}
			fprintf(fichier, "\n");
		}
	}
	fprintf(fichier, "\n    ]\n}");
	return 0;
}



